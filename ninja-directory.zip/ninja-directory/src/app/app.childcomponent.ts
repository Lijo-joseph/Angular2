import { Component } from '@angular/core';



@Component({
 selector: 'ChildComponent',

  template :'<h1>Movie ticket Booking</h1>',
  styleUrls: ['./app.childcomponent.css']

})

  

export class ChildComponent {

}

